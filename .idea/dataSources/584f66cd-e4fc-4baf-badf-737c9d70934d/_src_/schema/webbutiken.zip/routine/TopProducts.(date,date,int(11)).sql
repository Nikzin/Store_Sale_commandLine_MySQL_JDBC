CREATE PROCEDURE webbutiken.TopProducts(IN startdatum DATE, IN slutdatum DATE, IN antalprodukter INT)
  BEGIN

SELECT produkt.Namn AS Topprodukter, orderprodukt.Antal AS Antal FROM produkt
  INNER JOIN orderprodukt ON produkt.Kod = orderprodukt.Produktskod
   INNER JOIN  orders ON orderprodukt.OrderNr = orders.OrderNr
 WHERE orders.Datum BETWEEN startdatum AND slutdatum
  ORDER BY orderprodukt.Antal DESC

LIMIT antalprodukter;

END;
