CREATE TRIGGER webbutiken.SlutilagerTrigger
AFTER UPDATE ON webbutiken.produkt
FOR EACH ROW
  BEGIN
  IF (new.Tilgangligt=0)
    THEN INSERT INTO slutilager VALUES(current_date, old.Kod );
    END IF;
    END;
